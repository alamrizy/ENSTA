/*********************************************************************
	Rhapsody	: 8.1.1
	Login		: Le F�lix
	Component	: Exe
	Configuration 	: Host
	Model Element	: Host
//!	Generated Date	: Sat, 12, Mar 2016 
	File Path	: Exe/Host/MainExe.java
*********************************************************************/


//## auto_generated
import Scada.*;
//## auto_generated
import com.ibm.rational.rhapsody.oxf.*;
//## auto_generated
import com.ibm.rational.rhapsody.animcom.*;

//----------------------------------------------------------------------------
// MainExe.java                                                                  
//----------------------------------------------------------------------------


//## ignore 
public class MainExe {
    
    //#[ ignore
    // link with events in order to register them in the animation browser
    static {
      // Setting Animation Default Port 
      AnimTcpIpConnection.setDefaultPort(6423);
      // Registering Events 
      try {
        
            Class.forName("Scada.access");
            Class.forName("Scada.accessDenied");
            Class.forName("Scada.accessGranted");
            Class.forName("Scada.approved");
            Class.forName("Scada.approvedAccess");
            Class.forName("Scada.ch");
            Class.forName("Scada.check");
            Class.forName("Scada.checkRight");
            Class.forName("Scada.ckeckPolicy");
            Class.forName("Scada.connect");
            Class.forName("Scada.disconnect");
            Class.forName("Scada.end");
            Class.forName("Scada.forwardRequest");
            Class.forName("Scada.go");
            Class.forName("Scada.goAccess");
            Class.forName("Scada.granted");
            Class.forName("Scada.placeOrder");
            Class.forName("Scada.processing");
            Class.forName("Scada.reject");
            Class.forName("Scada.rejected");
            Class.forName("Scada.respond");
            Class.forName("Scada.violation");
    
        // Registering Static Classes 
        
      }
      catch(Exception e) { 
         java.lang.System.err.println(e.toString());
         e.printStackTrace(java.lang.System.err);
      }
    }
    //#]
    
    private Scada_pkgClass initializer_Scada = new Scada_pkgClass(RiJMainThread.instance());
    
    //## configuration Exe::Host 
    public static void main(String[] args) {
        RiJOXF.Init(null, 0, 0, true, args);
        MainExe initializer_Exe = new MainExe();
        //#[ configuration Exe::Host 
        //#]
        RiJOXF.Start();
    }
    
}
/*********************************************************************
	File Path	: Exe/Host/MainExe.java
*********************************************************************/


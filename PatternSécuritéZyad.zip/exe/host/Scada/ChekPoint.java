/*********************************************************************
	Rhapsody	: 8.1.1
	Login		: Le F�lix
	Component	: Exe
	Configuration 	: Host
	Model Element	: ChekPoint
//!	Generated Date	: Sat, 12, Mar 2016 
	File Path	: Exe/Host/Scada/ChekPoint.java
*********************************************************************/

package Scada;

//## auto_generated
import com.ibm.rational.rhapsody.oxf.*;
//## auto_generated
import com.ibm.rational.rhapsody.animation.*;
//## auto_generated
import com.ibm.rational.rhapsody.oxf.states.*;
//## auto_generated
import com.ibm.rational.rhapsody.animcom.animMessages.*;

//----------------------------------------------------------------------------
// Scada/ChekPoint.java                                                                  
//----------------------------------------------------------------------------

//## package Scada 


//## class ChekPoint 
public class ChekPoint implements RiJStateConcept, Animated {
    
    //#[ ignore
    // Instrumentation attributes (Animation)
    private Animate animate;
    
    public static AnimClass animClassChekPoint = new AnimClass("Scada.ChekPoint",false);
    //#]
    
    public Reactive reactive;		//## ignore 
    
    protected String policy;		//## attribute policy 
    
    protected ExternalComponent itsExternalComponent;		//## link itsExternalComponent 
    
    protected Rights itsRights;		//## link itsRights 
    
    protected ScadaProtectedSystem itsScadaProtectedSystem;		//## link itsScadaProtectedSystem 
    
    protected SecurityPolicy itsSecurityPolicy;		//## link itsSecurityPolicy 
    
    protected SingleAccessPoint itsSingleAccessPoint;		//## link itsSingleAccessPoint 
    
    protected SystemComponent itsSystemComponent;		//## link itsSystemComponent 
    
    //#[ ignore 
    public static final int RiJNonState=0;
    public static final int Transit=1;
    public static final int Rejected=2;
    public static final int Idle=3;
    public static final int Granted=4;
    public static final int Disconnected=5;
    public static final int Connected=6;
    //#]
    protected int rootState_subState;		//## ignore 
    
    protected int rootState_active;		//## ignore 
    
    
    //## statechart_method 
    public RiJThread getThread() {
        return reactive.getThread();
    }
    
    //## statechart_method 
    public void schedTimeout(long delay, long tmID, RiJStateReactive reactive) {
        getThread().schedTimeout(delay, tmID, reactive);
    }
    
    //## statechart_method 
    public void unschedTimeout(long tmID, RiJStateReactive reactive) {
        getThread().unschedTimeout(tmID, reactive);
    }
    
    //## statechart_method 
    public boolean isIn(int state) {
        return reactive.isIn(state);
    }
    
    //## statechart_method 
    public boolean isCompleted(int state) {
        return reactive.isCompleted(state);
    }
    
    //## statechart_method 
    public RiJEventConsumer getEventConsumer() {
        return (RiJEventConsumer)reactive;
    }
    
    //## statechart_method 
    public void gen(RiJEvent event) {
        reactive._gen(event);
    }
    
    //## statechart_method 
    public void queueEvent(RiJEvent event) {
        reactive.queueEvent(event);
    }
    
    //## statechart_method 
    public int takeEvent(RiJEvent event) {
        return reactive.takeEvent(event);
    }
    
    // Constructors
    
    //## auto_generated 
    public  ChekPoint(RiJThread p_thread) {
        try {
            animInstance().notifyConstructorEntered(animClassChekPoint.getUserClass(),
               new ArgData[] {
               });
        
        reactive = new Reactive(p_thread);
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    //## operation approvedAction() 
    public void approvedAction() {
        try {
            animInstance().notifyMethodEntered("approvedAction",
               new ArgData[] {
               });
        
        //#[ operation approvedAction() 
        this.SPS.gen(new forwardRequest());
        //#]
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    //## operation approvedAsseccAction() 
    public void approvedAsseccAction() {
        try {
            animInstance().notifyMethodEntered("approvedAsseccAction",
               new ArgData[] {
               });
        
        //#[ operation approvedAsseccAction() 
        this.SC.gen(new message());
        //#]
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    //## operation check() 
    public void check() {
        try {
            animInstance().notifyMethodEntered("check",
               new ArgData[] {
               });
        
        //#[ operation check() 
        //#]
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    /**
     * @param i
    */
    //## operation checkAction(int) 
    public void checkAction(int i) {
        try {
            animInstance().notifyMethodEntered("checkAction",
               new ArgData[] {
                   new ArgData(int.class, "i", AnimInstance.animToString(i))
               });
        
        //#[ operation checkAction(int) 
        this.SP.gen(new checkPolicy((int) i));
        //#]
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    //## operation grantedAction() 
    public void grantedAction() {
        try {
            animInstance().notifyMethodEntered("grantedAction",
               new ArgData[] {
               });
        
        //#[ operation grantedAction() 
        this.S.gen(new granted());
        //#]
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    //## operation rejectedAction() 
    public void rejectedAction() {
        try {
            animInstance().notifyMethodEntered("rejectedAction",
               new ArgData[] {
               });
        
        //#[ operation rejectedAction() 
        this.gen(new end());      
        
        this.S.gen(new rejected());
        //#]
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    //## TriggeredOperation requestAccess() 
    public void requestAccess() {
        try {
            animInstance().notifyTrgOpEntered("requestAccess",
               new ArgData[] {
               });
        
        requestAccess_ChekPoint_Event triggerEvent = new requestAccess_ChekPoint_Event();
        reactive.takeTrigger(triggerEvent);
        }
        finally {
            animInstance().notifyTrgOpExit();
        }
        
    }
    
    /**
     * @param i
    */
    //## operation requestAccessAction(int) 
    public void requestAccessAction(int i) {
        try {
            animInstance().notifyMethodEntered("requestAccessAction",
               new ArgData[] {
                   new ArgData(int.class, "i", AnimInstance.animToString(i))
               });
        
        //#[ operation requestAccessAction(int) 
        this.R.gen(new checkRight((int) i));
        //#]
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    //## operation respondAction() 
    public void respondAction() {
        try {
            animInstance().notifyMethodEntered("respondAction",
               new ArgData[] {
               });
        
        //#[ operation respondAction() 
        this.CP.gen(new connect());
        //#]
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    //## operation trigger_action() 
    public void trigger_action() {
        try {
            animInstance().notifyMethodEntered("trigger_action",
               new ArgData[] {
               });
        
        //#[ operation trigger_action() 
        //#]
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    //## operation violationAction() 
    public void violationAction() {
        try {
            animInstance().notifyMethodEntered("violationAction",
               new ArgData[] {
               });
        
        //#[ operation violationAction() 
        this.gen(new end());      
        
        this.SAP.gen(new disconnect());
        
        this.SC.gen(new triggerCounterMsg());
        //#]
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    //## auto_generated 
    public String getPolicy() {
        return policy;
    }
    
    //## auto_generated 
    public void setPolicy(String p_policy) {
        policy = p_policy;
    }
    
    //## auto_generated 
    public ExternalComponent getItsExternalComponent() {
        return itsExternalComponent;
    }
    
    //## auto_generated 
    public void __setItsExternalComponent(ExternalComponent p_ExternalComponent) {
        itsExternalComponent = p_ExternalComponent;
        if(p_ExternalComponent != null)
            {
                animInstance().notifyRelationAdded("itsExternalComponent", p_ExternalComponent);
            }
        else
            {
                animInstance().notifyRelationCleared("itsExternalComponent");
            }
    }
    
    //## auto_generated 
    public void _setItsExternalComponent(ExternalComponent p_ExternalComponent) {
        if(itsExternalComponent != null)
            {
                itsExternalComponent.__setItsChekPoint(null);
            }
        __setItsExternalComponent(p_ExternalComponent);
    }
    
    //## auto_generated 
    public void setItsExternalComponent(ExternalComponent p_ExternalComponent) {
        if(p_ExternalComponent != null)
            {
                p_ExternalComponent._setItsChekPoint(this);
            }
        _setItsExternalComponent(p_ExternalComponent);
    }
    
    //## auto_generated 
    public void _clearItsExternalComponent() {
        animInstance().notifyRelationCleared("itsExternalComponent");
        itsExternalComponent = null;
    }
    
    //## auto_generated 
    public Rights getItsRights() {
        return itsRights;
    }
    
    //## auto_generated 
    public void __setItsRights(Rights p_Rights) {
        itsRights = p_Rights;
        if(p_Rights != null)
            {
                animInstance().notifyRelationAdded("itsRights", p_Rights);
            }
        else
            {
                animInstance().notifyRelationCleared("itsRights");
            }
    }
    
    //## auto_generated 
    public void _setItsRights(Rights p_Rights) {
        if(itsRights != null)
            {
                itsRights.__setItsChekPoint(null);
            }
        __setItsRights(p_Rights);
    }
    
    //## auto_generated 
    public void setItsRights(Rights p_Rights) {
        if(p_Rights != null)
            {
                p_Rights._setItsChekPoint(this);
            }
        _setItsRights(p_Rights);
    }
    
    //## auto_generated 
    public void _clearItsRights() {
        animInstance().notifyRelationCleared("itsRights");
        itsRights = null;
    }
    
    //## auto_generated 
    public ScadaProtectedSystem getItsScadaProtectedSystem() {
        return itsScadaProtectedSystem;
    }
    
    //## auto_generated 
    public void __setItsScadaProtectedSystem(ScadaProtectedSystem p_ScadaProtectedSystem) {
        itsScadaProtectedSystem = p_ScadaProtectedSystem;
        if(p_ScadaProtectedSystem != null)
            {
                animInstance().notifyRelationAdded("itsScadaProtectedSystem", p_ScadaProtectedSystem);
            }
        else
            {
                animInstance().notifyRelationCleared("itsScadaProtectedSystem");
            }
    }
    
    //## auto_generated 
    public void _setItsScadaProtectedSystem(ScadaProtectedSystem p_ScadaProtectedSystem) {
        if(itsScadaProtectedSystem != null)
            {
                itsScadaProtectedSystem.__setItsChekPoint(null);
            }
        __setItsScadaProtectedSystem(p_ScadaProtectedSystem);
    }
    
    //## auto_generated 
    public void setItsScadaProtectedSystem(ScadaProtectedSystem p_ScadaProtectedSystem) {
        if(p_ScadaProtectedSystem != null)
            {
                p_ScadaProtectedSystem._setItsChekPoint(this);
            }
        _setItsScadaProtectedSystem(p_ScadaProtectedSystem);
    }
    
    //## auto_generated 
    public void _clearItsScadaProtectedSystem() {
        animInstance().notifyRelationCleared("itsScadaProtectedSystem");
        itsScadaProtectedSystem = null;
    }
    
    //## auto_generated 
    public SecurityPolicy getItsSecurityPolicy() {
        return itsSecurityPolicy;
    }
    
    //## auto_generated 
    public void __setItsSecurityPolicy(SecurityPolicy p_SecurityPolicy) {
        itsSecurityPolicy = p_SecurityPolicy;
        if(p_SecurityPolicy != null)
            {
                animInstance().notifyRelationAdded("itsSecurityPolicy", p_SecurityPolicy);
            }
        else
            {
                animInstance().notifyRelationCleared("itsSecurityPolicy");
            }
    }
    
    //## auto_generated 
    public void _setItsSecurityPolicy(SecurityPolicy p_SecurityPolicy) {
        if(itsSecurityPolicy != null)
            {
                itsSecurityPolicy.__setItsChekPoint(null);
            }
        __setItsSecurityPolicy(p_SecurityPolicy);
    }
    
    //## auto_generated 
    public void setItsSecurityPolicy(SecurityPolicy p_SecurityPolicy) {
        if(p_SecurityPolicy != null)
            {
                p_SecurityPolicy._setItsChekPoint(this);
            }
        _setItsSecurityPolicy(p_SecurityPolicy);
    }
    
    //## auto_generated 
    public void _clearItsSecurityPolicy() {
        animInstance().notifyRelationCleared("itsSecurityPolicy");
        itsSecurityPolicy = null;
    }
    
    //## auto_generated 
    public SingleAccessPoint getItsSingleAccessPoint() {
        return itsSingleAccessPoint;
    }
    
    //## auto_generated 
    public void __setItsSingleAccessPoint(SingleAccessPoint p_SingleAccessPoint) {
        itsSingleAccessPoint = p_SingleAccessPoint;
        if(p_SingleAccessPoint != null)
            {
                animInstance().notifyRelationAdded("itsSingleAccessPoint", p_SingleAccessPoint);
            }
        else
            {
                animInstance().notifyRelationCleared("itsSingleAccessPoint");
            }
    }
    
    //## auto_generated 
    public void _setItsSingleAccessPoint(SingleAccessPoint p_SingleAccessPoint) {
        if(itsSingleAccessPoint != null)
            {
                itsSingleAccessPoint.__setItsChekPoint(null);
            }
        __setItsSingleAccessPoint(p_SingleAccessPoint);
    }
    
    //## auto_generated 
    public void setItsSingleAccessPoint(SingleAccessPoint p_SingleAccessPoint) {
        if(p_SingleAccessPoint != null)
            {
                p_SingleAccessPoint._setItsChekPoint(this);
            }
        _setItsSingleAccessPoint(p_SingleAccessPoint);
    }
    
    //## auto_generated 
    public void _clearItsSingleAccessPoint() {
        animInstance().notifyRelationCleared("itsSingleAccessPoint");
        itsSingleAccessPoint = null;
    }
    
    //## auto_generated 
    public SystemComponent getItsSystemComponent() {
        return itsSystemComponent;
    }
    
    //## auto_generated 
    public void __setItsSystemComponent(SystemComponent p_SystemComponent) {
        itsSystemComponent = p_SystemComponent;
        if(p_SystemComponent != null)
            {
                animInstance().notifyRelationAdded("itsSystemComponent", p_SystemComponent);
            }
        else
            {
                animInstance().notifyRelationCleared("itsSystemComponent");
            }
    }
    
    //## auto_generated 
    public void _setItsSystemComponent(SystemComponent p_SystemComponent) {
        if(itsSystemComponent != null)
            {
                itsSystemComponent.__setItsChekPoint(null);
            }
        __setItsSystemComponent(p_SystemComponent);
    }
    
    //## auto_generated 
    public void setItsSystemComponent(SystemComponent p_SystemComponent) {
        if(p_SystemComponent != null)
            {
                p_SystemComponent._setItsChekPoint(this);
            }
        _setItsSystemComponent(p_SystemComponent);
    }
    
    //## auto_generated 
    public void _clearItsSystemComponent() {
        animInstance().notifyRelationCleared("itsSystemComponent");
        itsSystemComponent = null;
    }
    
    //## auto_generated 
    public boolean startBehavior() {
        boolean done = false;
        done = reactive.startBehavior();
        return done;
    }
    
    //## ignore 
    public class Reactive extends RiJStateReactive implements AnimatedReactive {
        
        // Default constructor 
        public Reactive() {
            this(RiJMainThread.instance());
        }
        
        
        // Constructors
        
        public  Reactive(RiJThread p_thread) {
            super(p_thread);
            initStatechart();
        }
        
        //## statechart_method 
        public boolean isIn(int state) {
            if(rootState_subState == state)
                {
                    return true;
                }
            return false;
        }
        
        //## statechart_method 
        public boolean isCompleted(int state) {
            return true;
        }
        
        //## statechart_method 
        public void rootState_add(AnimStates animStates) {
            animStates.add("ROOT");
            switch (rootState_subState) {
                case Idle:
                {
                    Idle_add(animStates);
                }
                break;
                case Transit:
                {
                    Transit_add(animStates);
                }
                break;
                case Rejected:
                {
                    Rejected_add(animStates);
                }
                break;
                case Granted:
                {
                    Granted_add(animStates);
                }
                break;
                case Connected:
                {
                    Connected_add(animStates);
                }
                break;
                case Disconnected:
                {
                    Disconnected_add(animStates);
                }
                break;
                default:
                    break;
            }
        }
        
        //## statechart_method 
        public void rootState_entDef() {
            {
                rootState_enter();
                rootStateEntDef();
            }
        }
        
        //## statechart_method 
        public int rootState_dispatchEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            switch (rootState_active) {
                case Idle:
                {
                    res = Idle_takeEvent(id);
                }
                break;
                case Transit:
                {
                    res = Transit_takeEvent(id);
                }
                break;
                case Rejected:
                {
                    res = Rejected_takeEvent(id);
                }
                break;
                case Granted:
                {
                    res = Granted_takeEvent(id);
                }
                break;
                case Connected:
                {
                    res = Connected_takeEvent(id);
                }
                break;
                case Disconnected:
                {
                    res = Disconnected_takeEvent(id);
                }
                break;
                default:
                    break;
            }
            return res;
        }
        
        //## statechart_method 
        public void Transit_add(AnimStates animStates) {
            animStates.add("ROOT.Transit");
        }
        
        //## statechart_method 
        public void Rejected_add(AnimStates animStates) {
            animStates.add("ROOT.Rejected");
        }
        
        //## statechart_method 
        public void Idle_add(AnimStates animStates) {
            animStates.add("ROOT.Idle");
        }
        
        //## statechart_method 
        public void Granted_add(AnimStates animStates) {
            animStates.add("ROOT.Granted");
        }
        
        //## statechart_method 
        public void Disconnected_add(AnimStates animStates) {
            animStates.add("ROOT.Disconnected");
        }
        
        //## statechart_method 
        public void Connected_add(AnimStates animStates) {
            animStates.add("ROOT.Connected");
        }
        
        //## auto_generated 
        protected void initStatechart() {
            rootState_subState = RiJNonState;
            rootState_active = RiJNonState;
        }
        
        //## statechart_method 
        public int DisconnectedTakeend() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("9");
            Disconnected_exit();
            Idle_entDef();
            animInstance().notifyTransitionEnded("9");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public void RejectedEnter() {
        }
        
        //## statechart_method 
        public void DisconnectedEnter() {
        }
        
        //## statechart_method 
        public void GrantedEnter() {
        }
        
        //## statechart_method 
        public void Connected_exit() {
            ConnectedExit();
            animInstance().notifyStateExited("ROOT.Connected");
        }
        
        //## statechart_method 
        public void Disconnected_entDef() {
            Disconnected_enter();
        }
        
        //## statechart_method 
        public void Rejected_exit() {
            RejectedExit();
            animInstance().notifyStateExited("ROOT.Rejected");
        }
        
        //## statechart_method 
        public void Transit_entDef() {
            Transit_enter();
        }
        
        //## statechart_method 
        public void Connected_enter() {
            animInstance().notifyStateEntered("ROOT.Connected");
            rootState_subState = Connected;
            rootState_active = Connected;
            ConnectedEnter();
        }
        
        //## statechart_method 
        public void Connected_entDef() {
            Connected_enter();
        }
        
        //## statechart_method 
        public void Disconnected_exit() {
            DisconnectedExit();
            animInstance().notifyStateExited("ROOT.Disconnected");
        }
        
        //## statechart_method 
        public void Granted_exit() {
            GrantedExit();
            animInstance().notifyStateExited("ROOT.Granted");
        }
        
        //## statechart_method 
        public int Rejected_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(end.end_Scada_id))
                {
                    res = RejectedTakeend();
                }
            
            return res;
        }
        
        //## statechart_method 
        public int ConnectedTakerespond() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("10");
            Connected_exit();
            //#[ transition 10 
            respondAction();
            //#]
            Idle_entDef();
            animInstance().notifyTransitionEnded("10");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public void GrantedExit() {
        }
        
        //## statechart_method 
        public int Idle_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(check.check_Scada_id))
                {
                    res = IdleTakecheck();
                }
            else if(event.isTypeOf(requestAccess_ChekPoint_Event.requestAccess_ChekPoint_Event_id))
                {
                    res = IdleTakerequestAccess_ChekPoint_Event();
                }
            
            return res;
        }
        
        //## statechart_method 
        public int IdleTakerequestAccess_ChekPoint_Event() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("1");
            Idle_exit();
            //#[ transition 1 
            requestAccessAction(params.security);
            //#]
            Transit_entDef();
            animInstance().notifyTransitionEnded("1");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public void Idle_enter() {
            animInstance().notifyStateEntered("ROOT.Idle");
            rootState_subState = Idle;
            rootState_active = Idle;
            IdleEnter();
        }
        
        //## statechart_method 
        public int rootState_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            return res;
        }
        
        //## statechart_method 
        public int IdleTakecheck() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("6");
            Idle_exit();
            //#[ transition 6 
            checkAction(params.checkSecurity);
            //#]
            Transit_entDef();
            animInstance().notifyTransitionEnded("6");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public void IdleExit() {
        }
        
        //## statechart_method 
        public void Idle_entDef() {
            Idle_enter();
        }
        
        //## statechart_method 
        public int GrantedTakegranted() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("5");
            Granted_exit();
            //#[ transition 5 
            grantedAction();
            //#]
            Idle_entDef();
            animInstance().notifyTransitionEnded("5");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public int RejectedTakeend() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("4");
            Rejected_exit();
            Idle_entDef();
            animInstance().notifyTransitionEnded("4");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public void Transit_enter() {
            animInstance().notifyStateEntered("ROOT.Transit");
            rootState_subState = Transit;
            rootState_active = Transit;
            TransitEnter();
        }
        
        //## statechart_method 
        public void rootState_enter() {
            animInstance().notifyStateEntered("ROOT");
            rootStateEnter();
        }
        
        //## statechart_method 
        public void rootStateEnter() {
        }
        
        //## statechart_method 
        public void ConnectedExit() {
        }
        
        //## statechart_method 
        public void Disconnected_enter() {
            animInstance().notifyStateEntered("ROOT.Disconnected");
            rootState_subState = Disconnected;
            rootState_active = Disconnected;
            DisconnectedEnter();
        }
        
        //## statechart_method 
        public void IdleEnter() {
        }
        
        //## statechart_method 
        public int TransitTakeapprovedAccess() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("7");
            Transit_exit();
            //#[ transition 7 
            approcedAccessAction();
            //#]
            Connected_entDef();
            animInstance().notifyTransitionEnded("7");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public void TransitEnter() {
        }
        
        //## statechart_method 
        public int Granted_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(granted.granted_Scada_id))
                {
                    res = GrantedTakegranted();
                }
            
            return res;
        }
        
        //## statechart_method 
        public void RejectedExit() {
        }
        
        //## statechart_method 
        public void Rejected_entDef() {
            Rejected_enter();
        }
        
        //## statechart_method 
        public void rootStateEntDef() {
            animInstance().notifyTransitionStarted("0");
            Idle_entDef();
            animInstance().notifyTransitionEnded("0");
        }
        
        //## statechart_method 
        public int Connected_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(respond.respond_Scada_id))
                {
                    res = ConnectedTakerespond();
                }
            
            return res;
        }
        
        //## statechart_method 
        public int Disconnected_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(end.end_Scada_id))
                {
                    res = DisconnectedTakeend();
                }
            
            return res;
        }
        
        //## statechart_method 
        public int TransitTakerejected() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("2");
            Transit_exit();
            //#[ transition 2 
            rejectedAction();
            //#]
            Rejected_entDef();
            animInstance().notifyTransitionEnded("2");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public void Idle_exit() {
            IdleExit();
            animInstance().notifyStateExited("ROOT.Idle");
        }
        
        //## statechart_method 
        public void Transit_exit() {
            TransitExit();
            animInstance().notifyStateExited("ROOT.Transit");
        }
        
        //## statechart_method 
        public void TransitExit() {
        }
        
        //## statechart_method 
        public void Granted_enter() {
            animInstance().notifyStateEntered("ROOT.Granted");
            rootState_subState = Granted;
            rootState_active = Granted;
            GrantedEnter();
        }
        
        //## statechart_method 
        public void Rejected_enter() {
            animInstance().notifyStateEntered("ROOT.Rejected");
            rootState_subState = Rejected;
            rootState_active = Rejected;
            RejectedEnter();
        }
        
        //## statechart_method 
        public void rootStateExit() {
        }
        
        //## statechart_method 
        public int TransitTakeapproved() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("3");
            Transit_exit();
            //#[ transition 3 
            approcedAction();
            //#]
            Granted_entDef();
            animInstance().notifyTransitionEnded("3");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public void ConnectedEnter() {
        }
        
        //## statechart_method 
        public void DisconnectedExit() {
        }
        
        //## statechart_method 
        public void Granted_entDef() {
            Granted_enter();
        }
        
        //## statechart_method 
        public int Transit_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(approvedAccess.approvedAccess_Scada_id))
                {
                    res = TransitTakeapprovedAccess();
                }
            else if(event.isTypeOf(rejected.rejected_Scada_id))
                {
                    res = TransitTakerejected();
                }
            else if(event.isTypeOf(approved.approved_Scada_id))
                {
                    res = TransitTakeapproved();
                }
            else if(event.isTypeOf(violation.violation_Scada_id))
                {
                    res = TransitTakeviolation();
                }
            
            return res;
        }
        
        //## statechart_method 
        public int TransitTakeviolation() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("8");
            Transit_exit();
            //#[ transition 8 
            violationAction();
            //#]
            Disconnected_entDef();
            animInstance().notifyTransitionEnded("8");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        /**  methods added just for design level debugging instrumentation */
        public boolean startBehavior() {
            try {
              animInstance().notifyBehavioralMethodEntered("startBehavior",
                  new ArgData[] {
                   });
              return super.startBehavior();
            }
            finally {
              animInstance().notifyMethodExit();
            }
        }
        public int takeEvent(RiJEvent event) { 
            try { 
              //animInstance().notifyTakeEvent(new AnimEvent(event));
              animInstance().notifyBehavioralMethodEntered("takeEvent",
                  new ArgData[] { new ArgData(RiJEvent.class, "event", event.toString())
                   });
              return super.takeEvent(event); 
            }
            finally { 
              animInstance().notifyMethodExit();
            }
        }
        /**  see com.ibm.rational.rhapsody.animation.AnimatedReactive interface */
        public AnimInstance animInstance() { 
            return ChekPoint.this.animInstance(); 
        }
        
    }
    //#[ ignore
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public AnimClass getAnimClass() { 
        return animClassChekPoint; 
    }
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public Object getFieldValue(java.lang.reflect.Field f, Object userInstance) { 
         Object obj = null;
         try {
             obj = f.get(userInstance);
         } catch(Exception e) {
              java.lang.System.err.println("Exception: getting Field value: " + e);
              e.printStackTrace();
         }
         return obj;
    }
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public AnimInstance animInstance() {
        if (animate == null) 
            animate = new Animate(); 
        return animate; 
    } 
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public void addAttributes(AnimAttributes msg) {
        
        msg.add("policy", policy);
    }
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public void addRelations(AnimRelations msg) {
        
        msg.add("itsExternalComponent", false, true, itsExternalComponent);
        msg.add("itsSystemComponent", false, true, itsSystemComponent);
        msg.add("itsSecurityPolicy", false, true, itsSecurityPolicy);
        msg.add("itsSingleAccessPoint", false, true, itsSingleAccessPoint);
        msg.add("itsRights", false, true, itsRights);
        msg.add("itsScadaProtectedSystem", false, true, itsScadaProtectedSystem);
    }
    /** An inner class added as instrumentation for animation */
    public class Animate extends AnimInstance { 
        public  Animate() { 
            super(ChekPoint.this); 
        } 
        public void addAttributes(AnimAttributes msg) {
            ChekPoint.this.addAttributes(msg);
        }
        public void addRelations(AnimRelations msg) {
            ChekPoint.this.addRelations(msg);
        }
        
        public void addStates(AnimStates msg) {
            if ((reactive != null) && (reactive.isTerminated() == false))
              reactive.rootState_add(msg);
        }
        
    } 
    //#]
    
}
//## ignore 
class requestAccess_ChekPoint_Event extends RiJEvent {
    
    public static final int requestAccess_ChekPoint_Event_id = 31000;
    
    // Constructors
    
    public  requestAccess_ChekPoint_Event() {
        lId = requestAccess_ChekPoint_Event_id;
    }
    
}
/*********************************************************************
	File Path	: Exe/Host/Scada/ChekPoint.java
*********************************************************************/


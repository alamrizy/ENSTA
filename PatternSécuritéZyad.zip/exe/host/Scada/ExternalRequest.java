/*********************************************************************
	Rhapsody	: 8.1.1
	Login		: Le F�lix
	Component	: Exe
	Configuration 	: Host
	Model Element	: ExternalRequest
//!	Generated Date	: Mon, 7, Mar 2016 
	File Path	: Exe/Host/Scada/ExternalRequest.java
*********************************************************************/

package Scada;

//## auto_generated
import com.ibm.rational.rhapsody.animation.*;
//## auto_generated
import com.ibm.rational.rhapsody.animcom.animMessages.*;

//----------------------------------------------------------------------------
// Scada/ExternalRequest.java                                                                  
//----------------------------------------------------------------------------

//## package Scada 


//## class ExternalRequest 
public class ExternalRequest implements Animated {
    
    //#[ ignore
    // Instrumentation attributes (Animation)
    private Animate animate;
    
    public static AnimClass animClassExternalRequest = new AnimClass("Scada.ExternalRequest",false);
    //#]
    
    protected SingleAccessPoint itsSingleAccessPoint;		//## link itsSingleAccessPoint 
    
    
    // Constructors
    
    //## auto_generated 
    public  ExternalRequest() {
        try {
            animInstance().notifyConstructorEntered(animClassExternalRequest.getUserClass(),
               new ArgData[] {
               });
        
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    //## auto_generated 
    public SingleAccessPoint getItsSingleAccessPoint() {
        return itsSingleAccessPoint;
    }
    
    //## auto_generated 
    public void __setItsSingleAccessPoint(SingleAccessPoint p_SingleAccessPoint) {
        itsSingleAccessPoint = p_SingleAccessPoint;
        if(p_SingleAccessPoint != null)
            {
                animInstance().notifyRelationAdded("itsSingleAccessPoint", p_SingleAccessPoint);
            }
        else
            {
                animInstance().notifyRelationCleared("itsSingleAccessPoint");
            }
    }
    
    //## auto_generated 
    public void _setItsSingleAccessPoint(SingleAccessPoint p_SingleAccessPoint) {
        if(itsSingleAccessPoint != null)
            {
                itsSingleAccessPoint.__setItsExternalRequest(null);
            }
        __setItsSingleAccessPoint(p_SingleAccessPoint);
    }
    
    //## auto_generated 
    public void setItsSingleAccessPoint(SingleAccessPoint p_SingleAccessPoint) {
        if(p_SingleAccessPoint != null)
            {
                p_SingleAccessPoint._setItsExternalRequest(this);
            }
        _setItsSingleAccessPoint(p_SingleAccessPoint);
    }
    
    //## auto_generated 
    public void _clearItsSingleAccessPoint() {
        animInstance().notifyRelationCleared("itsSingleAccessPoint");
        itsSingleAccessPoint = null;
    }
    
    //#[ ignore
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public AnimClass getAnimClass() { 
        return animClassExternalRequest; 
    }
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public Object getFieldValue(java.lang.reflect.Field f, Object userInstance) { 
         Object obj = null;
         try {
             obj = f.get(userInstance);
         } catch(Exception e) {
              java.lang.System.err.println("Exception: getting Field value: " + e);
              e.printStackTrace();
         }
         return obj;
    }
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public AnimInstance animInstance() {
        if (animate == null) 
            animate = new Animate(); 
        return animate; 
    } 
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public void addAttributes(AnimAttributes msg) {
        
    }
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public void addRelations(AnimRelations msg) {
        
        msg.add("itsSingleAccessPoint", false, true, itsSingleAccessPoint);
    }
    /** An inner class added as instrumentation for animation */
    public class Animate extends AnimInstance { 
        public  Animate() { 
            super(ExternalRequest.this); 
        } 
        public void addAttributes(AnimAttributes msg) {
            ExternalRequest.this.addAttributes(msg);
        }
        public void addRelations(AnimRelations msg) {
            ExternalRequest.this.addRelations(msg);
        }
        
    } 
    //#]
    
}
/*********************************************************************
	File Path	: Exe/Host/Scada/ExternalRequest.java
*********************************************************************/


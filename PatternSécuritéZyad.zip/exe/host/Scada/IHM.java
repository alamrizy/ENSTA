/*********************************************************************
	Rhapsody	: 8.1.1
	Login		: Le F�lix
	Component	: Exe
	Configuration 	: Host
	Model Element	: IHM
//!	Generated Date	: Mon, 7, Mar 2016 
	File Path	: Exe/Host/Scada/IHM.java
*********************************************************************/

package Scada;

//## auto_generated
import com.ibm.rational.rhapsody.animation.*;
//## auto_generated
import com.ibm.rational.rhapsody.animcom.animMessages.*;

//----------------------------------------------------------------------------
// Scada/IHM.java                                                                  
//----------------------------------------------------------------------------

//## package Scada 


//## class IHM 
public class IHM implements Animated {
    
    //#[ ignore
    // Instrumentation attributes (Animation)
    private Animate animate;
    
    public static AnimClass animClassIHM = new AnimClass("Scada.IHM",false);
    //#]
    
    protected CentralController itsCentralController;		//## link itsCentralController 
    
    
    // Constructors
    
    //## auto_generated 
    public  IHM() {
        try {
            animInstance().notifyConstructorEntered(animClassIHM.getUserClass(),
               new ArgData[] {
               });
        
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    //## auto_generated 
    public CentralController getItsCentralController() {
        return itsCentralController;
    }
    
    //## auto_generated 
    public void __setItsCentralController(CentralController p_CentralController) {
        itsCentralController = p_CentralController;
        if(p_CentralController != null)
            {
                animInstance().notifyRelationAdded("itsCentralController", p_CentralController);
            }
        else
            {
                animInstance().notifyRelationCleared("itsCentralController");
            }
    }
    
    //## auto_generated 
    public void _setItsCentralController(CentralController p_CentralController) {
        if(itsCentralController != null)
            {
                itsCentralController._removeItsIHM(this);
            }
        __setItsCentralController(p_CentralController);
    }
    
    //## auto_generated 
    public void setItsCentralController(CentralController p_CentralController) {
        if(p_CentralController != null)
            {
                p_CentralController._addItsIHM(this);
            }
        _setItsCentralController(p_CentralController);
    }
    
    //## auto_generated 
    public void _clearItsCentralController() {
        animInstance().notifyRelationCleared("itsCentralController");
        itsCentralController = null;
    }
    
    //#[ ignore
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public AnimClass getAnimClass() { 
        return animClassIHM; 
    }
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public Object getFieldValue(java.lang.reflect.Field f, Object userInstance) { 
         Object obj = null;
         try {
             obj = f.get(userInstance);
         } catch(Exception e) {
              java.lang.System.err.println("Exception: getting Field value: " + e);
              e.printStackTrace();
         }
         return obj;
    }
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public AnimInstance animInstance() {
        if (animate == null) 
            animate = new Animate(); 
        return animate; 
    } 
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public void addAttributes(AnimAttributes msg) {
        
    }
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public void addRelations(AnimRelations msg) {
        
        msg.add("itsCentralController", false, true, itsCentralController);
    }
    /** An inner class added as instrumentation for animation */
    public class Animate extends AnimInstance { 
        public  Animate() { 
            super(IHM.this); 
        } 
        public void addAttributes(AnimAttributes msg) {
            IHM.this.addAttributes(msg);
        }
        public void addRelations(AnimRelations msg) {
            IHM.this.addRelations(msg);
        }
        
    } 
    //#]
    
}
/*********************************************************************
	File Path	: Exe/Host/Scada/IHM.java
*********************************************************************/


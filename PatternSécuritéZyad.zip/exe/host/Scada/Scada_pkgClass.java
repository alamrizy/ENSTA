/*********************************************************************
	Rhapsody	: 8.1.1
	Login		: Le F�lix
	Component	: Exe
	Configuration 	: Host
	Model Element	: Scada
//!	Generated Date	: Sat, 12, Mar 2016 
	File Path	: Exe/Host/Scada/Scada_pkgClass.java
*********************************************************************/

package Scada;

//## auto_generated
import com.ibm.rational.rhapsody.oxf.*;
//## auto_generated
import com.ibm.rational.rhapsody.oxfinst.*;

//----------------------------------------------------------------------------
// Scada/Scada_pkgClass.java                                                                  
//----------------------------------------------------------------------------

//## package Scada 


//## ignore 
public class Scada_pkgClass {
    
    public static Customer C;		//## classInstance C 
    
    public static ChekPoint CP;		//## classInstance CP 
    
    public static CustomerRecord CR;		//## classInstance CR 
    
    public static ExternalComponent EC;		//## classInstance EC 
    
    public static Rights R;		//## classInstance R 
    
    public static Subject S;		//## classInstance S 
    
    public static SingleAccessPoint SAP;		//## classInstance SAP 
    
    public static SystemComponent SC;		//## classInstance SC 
    
    public static SecurityPolicy SP;		//## classInstance SP 
    
    public static ScadaProtectedSystem SPS;		//## classInstance SPS 
    
    
    // Constructors
    
    //## auto_generated 
    public  Scada_pkgClass(RiJThread p_thread) {
        initRelations(p_thread);
        startBehavior();
    }
    
    //## auto_generated 
    protected void finalize() throws Throwable {
        
        super.finalize();
    }
    
    private static void renameGlobalInstances() {
        if(S != null)
            {
                AnimServices.setInstanceName(S, "S");
            }
        if(R != null)
            {
                AnimServices.setInstanceName(R, "R");
            }
        if(SPS != null)
            {
                AnimServices.setInstanceName(SPS, "SPS");
            }
        if(EC != null)
            {
                AnimServices.setInstanceName(EC, "EC");
            }
        if(CP != null)
            {
                AnimServices.setInstanceName(CP, "CP");
            }
        if(SC != null)
            {
                AnimServices.setInstanceName(SC, "SC");
            }
        if(SP != null)
            {
                AnimServices.setInstanceName(SP, "SP");
            }
        if(C != null)
            {
                AnimServices.setInstanceName(C, "C");
            }
        if(SAP != null)
            {
                AnimServices.setInstanceName(SAP, "SAP");
            }
        if(CR != null)
            {
                AnimServices.setInstanceName(CR, "CR");
            }
    }
    
    //## auto_generated 
    protected void initRelations(RiJThread p_thread) {
        C = new Customer(p_thread);
        CP = new ChekPoint(p_thread);
        CR = new CustomerRecord(p_thread);
        EC = new ExternalComponent(p_thread);
        R = new Rights(p_thread);
        S = new Subject(p_thread);
        SAP = new SingleAccessPoint(p_thread);
        SC = new SystemComponent(p_thread);
        SP = new SecurityPolicy(p_thread);
        SPS = new ScadaProtectedSystem(p_thread);
        R.setItsScadaProtectedSystem(SPS);
        R.setItsSubject(S);
        SPS.setItsSubject(S);
        SC.setItsChekPoint(CP);
        CP.setItsExternalComponent(EC);
        CP.setItsSecurityPolicy(SP);
        C.setItsSingleAccessPoint(SAP);
        SAP.setItsCustomerRecord(CR);
        renameGlobalInstances();
    }
    
    //## auto_generated 
    public boolean startBehavior() {
        boolean done = true;
        done &= C.startBehavior();
        done &= CP.startBehavior();
        done &= CR.startBehavior();
        done &= EC.startBehavior();
        done &= R.startBehavior();
        done &= S.startBehavior();
        done &= SAP.startBehavior();
        done &= SC.startBehavior();
        done &= SP.startBehavior();
        done &= SPS.startBehavior();
        return done;
    }
    
}
/*********************************************************************
	File Path	: Exe/Host/Scada/Scada_pkgClass.java
*********************************************************************/


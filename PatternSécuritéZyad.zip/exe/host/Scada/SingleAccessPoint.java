/*********************************************************************
	Rhapsody	: 8.1.1
	Login		: Le F�lix
	Component	: Exe
	Configuration 	: Host
	Model Element	: SingleAccessPoint
//!	Generated Date	: Sat, 12, Mar 2016 
	File Path	: Exe/Host/Scada/SingleAccessPoint.java
*********************************************************************/

package Scada;

//## auto_generated
import com.ibm.rational.rhapsody.oxf.*;
//## auto_generated
import com.ibm.rational.rhapsody.animation.*;
//## auto_generated
import com.ibm.rational.rhapsody.oxf.states.*;
//## auto_generated
import com.ibm.rational.rhapsody.animcom.animMessages.*;

//----------------------------------------------------------------------------
// Scada/SingleAccessPoint.java                                                                  
//----------------------------------------------------------------------------

//## package Scada 


//## class SingleAccessPoint 
public class SingleAccessPoint implements RiJStateConcept, Animated {
    
    //#[ ignore
    // Instrumentation attributes (Animation)
    private Animate animate;
    
    public static AnimClass animClassSingleAccessPoint = new AnimClass("Scada.SingleAccessPoint",false);
    //#]
    
    public Reactive reactive;		//## ignore 
    
    protected String access_log;		//## attribute access_log 
    
    protected String authorization_information;		//## attribute authorization_information 
    
    protected int checkSecurity = (int)(Math.random()*1)+1;		//## attribute checkSecurity 
    
    protected ChekPoint itsChekPoint;		//## link itsChekPoint 
    
    protected Customer itsCustomer;		//## link itsCustomer 
    
    protected CustomerRecord itsCustomerRecord;		//## link itsCustomerRecord 
    
    protected CustomerRecord itsCustomerRecord_1;		//## link itsCustomerRecord_1 
    
    protected ExternalRequest itsExternalRequest;		//## link itsExternalRequest 
    
    //#[ ignore 
    public static final int RiJNonState=0;
    public static final int Transit=1;
    public static final int PlaceOrder=2;
    public static final int Idle=3;
    public static final int Disconnected=4;
    public static final int Connected=5;
    //#]
    protected int rootState_subState;		//## ignore 
    
    protected int rootState_active;		//## ignore 
    
    
    //## statechart_method 
    public RiJThread getThread() {
        return reactive.getThread();
    }
    
    //## statechart_method 
    public void schedTimeout(long delay, long tmID, RiJStateReactive reactive) {
        getThread().schedTimeout(delay, tmID, reactive);
    }
    
    //## statechart_method 
    public void unschedTimeout(long tmID, RiJStateReactive reactive) {
        getThread().unschedTimeout(tmID, reactive);
    }
    
    //## statechart_method 
    public boolean isIn(int state) {
        return reactive.isIn(state);
    }
    
    //## statechart_method 
    public boolean isCompleted(int state) {
        return reactive.isCompleted(state);
    }
    
    //## statechart_method 
    public RiJEventConsumer getEventConsumer() {
        return (RiJEventConsumer)reactive;
    }
    
    //## statechart_method 
    public void gen(RiJEvent event) {
        reactive._gen(event);
    }
    
    //## statechart_method 
    public void queueEvent(RiJEvent event) {
        reactive.queueEvent(event);
    }
    
    //## statechart_method 
    public int takeEvent(RiJEvent event) {
        return reactive.takeEvent(event);
    }
    
    // Constructors
    
    //## auto_generated 
    public  SingleAccessPoint(RiJThread p_thread) {
        try {
            animInstance().notifyConstructorEntered(animClassSingleAccessPoint.getUserClass(),
               new ArgData[] {
               });
        
        reactive = new Reactive(p_thread);
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    /**
     * @param caract
    */
    //## operation access(String) 
    public void access(final String caract) {
        try {
            animInstance().notifyMethodEntered("access",
               new ArgData[] {
                   new ArgData(String.class, "caract", AnimInstance.animToString(caract))
               });
        
        //#[ operation access(String) 
        this.gen(new processing());      
        
        this.CR.gen(new placeOrder(caract));
        //#]
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    //## operation connectAction() 
    public void connectAction() {
        try {
            animInstance().notifyMethodEntered("connectAction",
               new ArgData[] {
               });
        
        //#[ operation connectAction() 
        this.gen(new end());   
        
        this.EC.gen(new accessGranted());
        //#]
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    //## operation disconnectAction() 
    public void disconnectAction() {
        try {
            animInstance().notifyMethodEntered("disconnectAction",
               new ArgData[] {
               });
        
        //#[ operation disconnectAction() 
        this.gen(new end());      
        
        this.EC.gen(new accessDinied());
        //#]
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    //## TriggeredOperation message() 
    public void message() {
        try {
            animInstance().notifyTrgOpEntered("message",
               new ArgData[] {
               });
        
        message_SingleAccessPoint_Event triggerEvent = new message_SingleAccessPoint_Event();
        reactive.takeTrigger(triggerEvent);
        }
        finally {
            animInstance().notifyTrgOpExit();
        }
        
    }
    
    /**
     * @param i
    */
    //## operation messageAction(int) 
    public void messageAction(int i) {
        try {
            animInstance().notifyMethodEntered("messageAction",
               new ArgData[] {
                   new ArgData(int.class, "i", AnimInstance.animToString(i))
               });
        
        //#[ operation messageAction(int) 
        this.gen(new end());   
        
        this.CP.gen(new check((int) checkSecurity));
        //#]
        }
        finally {
            animInstance().notifyMethodExit();
        }
        
    }
    
    //## auto_generated 
    public String getAccess_log() {
        return access_log;
    }
    
    //## auto_generated 
    public void setAccess_log(String p_access_log) {
        access_log = p_access_log;
    }
    
    //## auto_generated 
    public String getAuthorization_information() {
        return authorization_information;
    }
    
    //## auto_generated 
    public void setAuthorization_information(String p_authorization_information) {
        authorization_information = p_authorization_information;
    }
    
    //## auto_generated 
    public int getCheckSecurity() {
        return checkSecurity;
    }
    
    //## auto_generated 
    public void setCheckSecurity(int p_checkSecurity) {
        checkSecurity = p_checkSecurity;
    }
    
    //## auto_generated 
    public ChekPoint getItsChekPoint() {
        return itsChekPoint;
    }
    
    //## auto_generated 
    public void __setItsChekPoint(ChekPoint p_ChekPoint) {
        itsChekPoint = p_ChekPoint;
        if(p_ChekPoint != null)
            {
                animInstance().notifyRelationAdded("itsChekPoint", p_ChekPoint);
            }
        else
            {
                animInstance().notifyRelationCleared("itsChekPoint");
            }
    }
    
    //## auto_generated 
    public void _setItsChekPoint(ChekPoint p_ChekPoint) {
        if(itsChekPoint != null)
            {
                itsChekPoint.__setItsSingleAccessPoint(null);
            }
        __setItsChekPoint(p_ChekPoint);
    }
    
    //## auto_generated 
    public void setItsChekPoint(ChekPoint p_ChekPoint) {
        if(p_ChekPoint != null)
            {
                p_ChekPoint._setItsSingleAccessPoint(this);
            }
        _setItsChekPoint(p_ChekPoint);
    }
    
    //## auto_generated 
    public void _clearItsChekPoint() {
        animInstance().notifyRelationCleared("itsChekPoint");
        itsChekPoint = null;
    }
    
    //## auto_generated 
    public Customer getItsCustomer() {
        return itsCustomer;
    }
    
    //## auto_generated 
    public void __setItsCustomer(Customer p_Customer) {
        itsCustomer = p_Customer;
        if(p_Customer != null)
            {
                animInstance().notifyRelationAdded("itsCustomer", p_Customer);
            }
        else
            {
                animInstance().notifyRelationCleared("itsCustomer");
            }
    }
    
    //## auto_generated 
    public void _setItsCustomer(Customer p_Customer) {
        if(itsCustomer != null)
            {
                itsCustomer.__setItsSingleAccessPoint(null);
            }
        __setItsCustomer(p_Customer);
    }
    
    //## auto_generated 
    public void setItsCustomer(Customer p_Customer) {
        if(p_Customer != null)
            {
                p_Customer._setItsSingleAccessPoint(this);
            }
        _setItsCustomer(p_Customer);
    }
    
    //## auto_generated 
    public void _clearItsCustomer() {
        animInstance().notifyRelationCleared("itsCustomer");
        itsCustomer = null;
    }
    
    //## auto_generated 
    public CustomerRecord getItsCustomerRecord() {
        return itsCustomerRecord;
    }
    
    //## auto_generated 
    public void __setItsCustomerRecord(CustomerRecord p_CustomerRecord) {
        itsCustomerRecord = p_CustomerRecord;
        if(p_CustomerRecord != null)
            {
                animInstance().notifyRelationAdded("itsCustomerRecord", p_CustomerRecord);
            }
        else
            {
                animInstance().notifyRelationCleared("itsCustomerRecord");
            }
    }
    
    //## auto_generated 
    public void _setItsCustomerRecord(CustomerRecord p_CustomerRecord) {
        if(itsCustomerRecord != null)
            {
                itsCustomerRecord.__setItsSingleAccessPoint(null);
            }
        __setItsCustomerRecord(p_CustomerRecord);
    }
    
    //## auto_generated 
    public void setItsCustomerRecord(CustomerRecord p_CustomerRecord) {
        if(p_CustomerRecord != null)
            {
                p_CustomerRecord._setItsSingleAccessPoint(this);
            }
        _setItsCustomerRecord(p_CustomerRecord);
    }
    
    //## auto_generated 
    public void _clearItsCustomerRecord() {
        animInstance().notifyRelationCleared("itsCustomerRecord");
        itsCustomerRecord = null;
    }
    
    //## auto_generated 
    public CustomerRecord getItsCustomerRecord_1() {
        return itsCustomerRecord_1;
    }
    
    //## auto_generated 
    public void __setItsCustomerRecord_1(CustomerRecord p_CustomerRecord) {
        itsCustomerRecord_1 = p_CustomerRecord;
        if(p_CustomerRecord != null)
            {
                animInstance().notifyRelationAdded("itsCustomerRecord_1", p_CustomerRecord);
            }
        else
            {
                animInstance().notifyRelationCleared("itsCustomerRecord_1");
            }
    }
    
    //## auto_generated 
    public void _setItsCustomerRecord_1(CustomerRecord p_CustomerRecord) {
        if(itsCustomerRecord_1 != null)
            {
                itsCustomerRecord_1.__setItsSingleAccessPoint_1(null);
            }
        __setItsCustomerRecord_1(p_CustomerRecord);
    }
    
    //## auto_generated 
    public void setItsCustomerRecord_1(CustomerRecord p_CustomerRecord) {
        if(p_CustomerRecord != null)
            {
                p_CustomerRecord._setItsSingleAccessPoint_1(this);
            }
        _setItsCustomerRecord_1(p_CustomerRecord);
    }
    
    //## auto_generated 
    public void _clearItsCustomerRecord_1() {
        animInstance().notifyRelationCleared("itsCustomerRecord_1");
        itsCustomerRecord_1 = null;
    }
    
    //## auto_generated 
    public ExternalRequest getItsExternalRequest() {
        return itsExternalRequest;
    }
    
    //## auto_generated 
    public void __setItsExternalRequest(ExternalRequest p_ExternalRequest) {
        itsExternalRequest = p_ExternalRequest;
        if(p_ExternalRequest != null)
            {
                animInstance().notifyRelationAdded("itsExternalRequest", p_ExternalRequest);
            }
        else
            {
                animInstance().notifyRelationCleared("itsExternalRequest");
            }
    }
    
    //## auto_generated 
    public void _setItsExternalRequest(ExternalRequest p_ExternalRequest) {
        if(itsExternalRequest != null)
            {
                itsExternalRequest.__setItsSingleAccessPoint(null);
            }
        __setItsExternalRequest(p_ExternalRequest);
    }
    
    //## auto_generated 
    public void setItsExternalRequest(ExternalRequest p_ExternalRequest) {
        if(p_ExternalRequest != null)
            {
                p_ExternalRequest._setItsSingleAccessPoint(this);
            }
        _setItsExternalRequest(p_ExternalRequest);
    }
    
    //## auto_generated 
    public void _clearItsExternalRequest() {
        animInstance().notifyRelationCleared("itsExternalRequest");
        itsExternalRequest = null;
    }
    
    //## auto_generated 
    public boolean startBehavior() {
        boolean done = false;
        done = reactive.startBehavior();
        return done;
    }
    
    //## ignore 
    public class Reactive extends RiJStateReactive implements AnimatedReactive {
        
        // Default constructor 
        public Reactive() {
            this(RiJMainThread.instance());
        }
        
        
        // Constructors
        
        public  Reactive(RiJThread p_thread) {
            super(p_thread);
            initStatechart();
        }
        
        //## statechart_method 
        public boolean isIn(int state) {
            if(rootState_subState == state)
                {
                    return true;
                }
            return false;
        }
        
        //## statechart_method 
        public boolean isCompleted(int state) {
            return true;
        }
        
        //## statechart_method 
        public void rootState_add(AnimStates animStates) {
            animStates.add("ROOT");
            switch (rootState_subState) {
                case Idle:
                {
                    Idle_add(animStates);
                }
                break;
                case Transit:
                {
                    Transit_add(animStates);
                }
                break;
                case Connected:
                {
                    Connected_add(animStates);
                }
                break;
                case Disconnected:
                {
                    Disconnected_add(animStates);
                }
                break;
                case PlaceOrder:
                {
                    PlaceOrder_add(animStates);
                }
                break;
                default:
                    break;
            }
        }
        
        //## statechart_method 
        public void rootState_entDef() {
            {
                rootState_enter();
                rootStateEntDef();
            }
        }
        
        //## statechart_method 
        public int rootState_dispatchEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            switch (rootState_active) {
                case Idle:
                {
                    res = Idle_takeEvent(id);
                }
                break;
                case Transit:
                {
                    res = Transit_takeEvent(id);
                }
                break;
                case Connected:
                {
                    res = Connected_takeEvent(id);
                }
                break;
                case Disconnected:
                {
                    res = Disconnected_takeEvent(id);
                }
                break;
                case PlaceOrder:
                {
                    res = PlaceOrder_takeEvent(id);
                }
                break;
                default:
                    break;
            }
            return res;
        }
        
        //## statechart_method 
        public void Transit_add(AnimStates animStates) {
            animStates.add("ROOT.Transit");
        }
        
        //## statechart_method 
        public void PlaceOrder_add(AnimStates animStates) {
            animStates.add("ROOT.PlaceOrder");
        }
        
        //## statechart_method 
        public void Idle_add(AnimStates animStates) {
            animStates.add("ROOT.Idle");
        }
        
        //## statechart_method 
        public void Disconnected_add(AnimStates animStates) {
            animStates.add("ROOT.Disconnected");
        }
        
        //## statechart_method 
        public void Connected_add(AnimStates animStates) {
            animStates.add("ROOT.Connected");
        }
        
        //## auto_generated 
        protected void initStatechart() {
            rootState_subState = RiJNonState;
            rootState_active = RiJNonState;
        }
        
        //## statechart_method 
        public int DisconnectedTakeend() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("4");
            Disconnected_exit();
            Idle_entDef();
            animInstance().notifyTransitionEnded("4");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public int ConnectedTakeend() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("5");
            Connected_exit();
            Idle_entDef();
            animInstance().notifyTransitionEnded("5");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public void DisconnectedEnter() {
        }
        
        //## statechart_method 
        public void Connected_exit() {
            ConnectedExit();
            animInstance().notifyStateExited("ROOT.Connected");
        }
        
        //## statechart_method 
        public void Disconnected_entDef() {
            Disconnected_enter();
        }
        
        //## statechart_method 
        public void Transit_entDef() {
            Transit_enter();
        }
        
        //## statechart_method 
        public void Connected_enter() {
            animInstance().notifyStateEntered("ROOT.Connected");
            rootState_subState = Connected;
            rootState_active = Connected;
            ConnectedEnter();
        }
        
        //## statechart_method 
        public void Connected_entDef() {
            Connected_enter();
        }
        
        //## statechart_method 
        public void Disconnected_exit() {
            DisconnectedExit();
            animInstance().notifyStateExited("ROOT.Disconnected");
        }
        
        //## statechart_method 
        public void PlaceOrderEnter() {
        }
        
        //## statechart_method 
        public int Idle_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(message_SingleAccessPoint_Event.message_SingleAccessPoint_Event_id))
                {
                    res = IdleTakemessage_SingleAccessPoint_Event();
                }
            else if(event.isTypeOf(goAccess.goAccess_Scada_id))
                {
                    res = IdleTakegoAccess();
                }
            
            return res;
        }
        
        //## statechart_method 
        public void Idle_enter() {
            animInstance().notifyStateEntered("ROOT.Idle");
            rootState_subState = Idle;
            rootState_active = Idle;
            IdleEnter();
        }
        
        //## statechart_method 
        public int rootState_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            return res;
        }
        
        //## statechart_method 
        public void IdleExit() {
        }
        
        //## statechart_method 
        public void Idle_entDef() {
            Idle_enter();
        }
        
        //## statechart_method 
        public int PlaceOrderTakeNull() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("8");
            PlaceOrder_exit();
            Idle_entDef();
            animInstance().notifyTransitionEnded("8");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public void PlaceOrder_exit() {
            popNullConfig();
            PlaceOrderExit();
            animInstance().notifyStateExited("ROOT.PlaceOrder");
        }
        
        //## statechart_method 
        public void PlaceOrder_entDef() {
            PlaceOrder_enter();
        }
        
        //## statechart_method 
        public int TransitTakeprocessing() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("7");
            Transit_exit();
            PlaceOrder_entDef();
            animInstance().notifyTransitionEnded("7");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public int IdleTakegoAccess() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("6");
            Idle_exit();
            //#[ transition 6 
            access(params.placeOrder);
            //#]
            Transit_entDef();
            animInstance().notifyTransitionEnded("6");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public void Transit_enter() {
            animInstance().notifyStateEntered("ROOT.Transit");
            rootState_subState = Transit;
            rootState_active = Transit;
            TransitEnter();
        }
        
        //## statechart_method 
        public void rootState_enter() {
            animInstance().notifyStateEntered("ROOT");
            rootStateEnter();
        }
        
        //## statechart_method 
        public void rootStateEnter() {
        }
        
        //## statechart_method 
        public void ConnectedExit() {
        }
        
        //## statechart_method 
        public void Disconnected_enter() {
            animInstance().notifyStateEntered("ROOT.Disconnected");
            rootState_subState = Disconnected;
            rootState_active = Disconnected;
            DisconnectedEnter();
        }
        
        //## statechart_method 
        public void PlaceOrder_enter() {
            animInstance().notifyStateEntered("ROOT.PlaceOrder");
            pushNullConfig();
            rootState_subState = PlaceOrder;
            rootState_active = PlaceOrder;
            PlaceOrderEnter();
        }
        
        //## statechart_method 
        public void IdleEnter() {
        }
        
        //## statechart_method 
        public int TransitTakeconnect() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("2");
            Transit_exit();
            //#[ transition 2 
            connectAction();
            //#]
            Connected_entDef();
            animInstance().notifyTransitionEnded("2");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public void TransitEnter() {
        }
        
        //## statechart_method 
        public void rootStateEntDef() {
            animInstance().notifyTransitionStarted("0");
            Idle_entDef();
            animInstance().notifyTransitionEnded("0");
        }
        
        //## statechart_method 
        public int Connected_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(end.end_Scada_id))
                {
                    res = ConnectedTakeend();
                }
            
            return res;
        }
        
        //## statechart_method 
        public int Disconnected_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(end.end_Scada_id))
                {
                    res = DisconnectedTakeend();
                }
            
            return res;
        }
        
        //## statechart_method 
        public int PlaceOrder_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(RiJEvent.NULL_EVENT_ID))
                {
                    res = PlaceOrderTakeNull();
                }
            
            return res;
        }
        
        //## statechart_method 
        public int IdleTakemessage_SingleAccessPoint_Event() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("1");
            Idle_exit();
            //#[ transition 1 
            messageAction();
            //#]
            Transit_entDef();
            animInstance().notifyTransitionEnded("1");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public void Idle_exit() {
            IdleExit();
            animInstance().notifyStateExited("ROOT.Idle");
        }
        
        //## statechart_method 
        public int TransitTakedisconnect() {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            animInstance().notifyTransitionStarted("3");
            Transit_exit();
            //#[ transition 3 
            disconnectAction();
            //#]
            Disconnected_entDef();
            animInstance().notifyTransitionEnded("3");
            res = RiJStateReactive.TAKE_EVENT_COMPLETE;
            return res;
        }
        
        //## statechart_method 
        public void Transit_exit() {
            TransitExit();
            animInstance().notifyStateExited("ROOT.Transit");
        }
        
        //## statechart_method 
        public void TransitExit() {
        }
        
        //## statechart_method 
        public void rootStateExit() {
        }
        
        //## statechart_method 
        public void PlaceOrderExit() {
        }
        
        //## statechart_method 
        public void ConnectedEnter() {
        }
        
        //## statechart_method 
        public void DisconnectedExit() {
        }
        
        //## statechart_method 
        public int Transit_takeEvent(short id) {
            int res = RiJStateReactive.TAKE_EVENT_NOT_CONSUMED;
            if(event.isTypeOf(processing.processing_Scada_id))
                {
                    res = TransitTakeprocessing();
                }
            else if(event.isTypeOf(connect.connect_Scada_id))
                {
                    res = TransitTakeconnect();
                }
            else if(event.isTypeOf(disconnect.disconnect_Scada_id))
                {
                    res = TransitTakedisconnect();
                }
            
            return res;
        }
        
        /**  methods added just for design level debugging instrumentation */
        public boolean startBehavior() {
            try {
              animInstance().notifyBehavioralMethodEntered("startBehavior",
                  new ArgData[] {
                   });
              return super.startBehavior();
            }
            finally {
              animInstance().notifyMethodExit();
            }
        }
        public int takeEvent(RiJEvent event) { 
            try { 
              //animInstance().notifyTakeEvent(new AnimEvent(event));
              animInstance().notifyBehavioralMethodEntered("takeEvent",
                  new ArgData[] { new ArgData(RiJEvent.class, "event", event.toString())
                   });
              return super.takeEvent(event); 
            }
            finally { 
              animInstance().notifyMethodExit();
            }
        }
        /**  see com.ibm.rational.rhapsody.animation.AnimatedReactive interface */
        public AnimInstance animInstance() { 
            return SingleAccessPoint.this.animInstance(); 
        }
        
    }
    //#[ ignore
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public AnimClass getAnimClass() { 
        return animClassSingleAccessPoint; 
    }
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public Object getFieldValue(java.lang.reflect.Field f, Object userInstance) { 
         Object obj = null;
         try {
             obj = f.get(userInstance);
         } catch(Exception e) {
              java.lang.System.err.println("Exception: getting Field value: " + e);
              e.printStackTrace();
         }
         return obj;
    }
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public AnimInstance animInstance() {
        if (animate == null) 
            animate = new Animate(); 
        return animate; 
    } 
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public void addAttributes(AnimAttributes msg) {
        
        msg.add("authorization_information", authorization_information);
        msg.add("access_log", access_log);
        msg.add("checkSecurity", checkSecurity);
    }
    /**  see com.ibm.rational.rhapsody.animation.Animated interface */
    public void addRelations(AnimRelations msg) {
        
        msg.add("itsCustomerRecord", false, true, itsCustomerRecord);
        msg.add("itsCustomer", false, true, itsCustomer);
        msg.add("itsCustomerRecord_1", false, true, itsCustomerRecord_1);
        msg.add("itsExternalRequest", false, true, itsExternalRequest);
        msg.add("itsChekPoint", false, true, itsChekPoint);
    }
    /** An inner class added as instrumentation for animation */
    public class Animate extends AnimInstance { 
        public  Animate() { 
            super(SingleAccessPoint.this); 
        } 
        public void addAttributes(AnimAttributes msg) {
            SingleAccessPoint.this.addAttributes(msg);
        }
        public void addRelations(AnimRelations msg) {
            SingleAccessPoint.this.addRelations(msg);
        }
        
        public void addStates(AnimStates msg) {
            if ((reactive != null) && (reactive.isTerminated() == false))
              reactive.rootState_add(msg);
        }
        
    } 
    //#]
    
}
//## ignore 
class message_SingleAccessPoint_Event extends RiJEvent {
    
    public static final int message_SingleAccessPoint_Event_id = 31000;
    
    // Constructors
    
    public  message_SingleAccessPoint_Event() {
        lId = message_SingleAccessPoint_Event_id;
    }
    
}
/*********************************************************************
	File Path	: Exe/Host/Scada/SingleAccessPoint.java
*********************************************************************/


/*********************************************************************
	Rhapsody	: 8.1.1
	Login		: Le F�lix
	Component	: Exe
	Configuration 	: Host
	Model Element	: access
//!	Generated Date	: Sat, 12, Mar 2016 
	File Path	: Exe/Host/Scada/access.java
*********************************************************************/

package Scada;

//## auto_generated
import com.ibm.rational.rhapsody.animation.*;
//## auto_generated
import com.ibm.rational.rhapsody.oxf.RiJEvent;
//## auto_generated
import com.ibm.rational.rhapsody.animcom.animMessages.*;

//----------------------------------------------------------------------------
// Scada/access.java                                                                  
//----------------------------------------------------------------------------

//## package Scada 


//## event access() 
public class access extends RiJEvent implements AnimatedEvent {
    
    public static final int access_Scada_id = 2834;		//## ignore 
    
    
    // Constructors
    
    public  access() {
        lId = access_Scada_id;
    }
    
    public boolean isTypeOf(long id) {
        return (access_Scada_id==id);
    }
    
    //#[ ignore
    /** the animated event proxy */
    public static AnimEventClass animClass = new AnimEventClass("Scada.access");
    /**  see com.ibm.rational.rhapsody.animation.AnimatedEvent interface */
    public Object getFieldValue(java.lang.reflect.Field f, Object userInstance) { 
         Object obj = null;
         try {
             obj = f.get(userInstance);
         } catch(Exception e) {
              java.lang.System.err.println("Exception: getting Field value: " + e);
              e.printStackTrace();
         }
         return obj;
    }
    /**  see com.ibm.rational.rhapsody.animation.AnimatedEvent interface */
    public void addAttributes(AnimAttributes msg) {      
    }
    public String toString() {
          String s="access(";      
          s += ")";
          return s;
    }
    //#]
    
}
/*********************************************************************
	File Path	: Exe/Host/Scada/access.java
*********************************************************************/


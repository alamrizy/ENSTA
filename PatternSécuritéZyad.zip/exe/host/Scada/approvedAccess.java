/*********************************************************************
	Rhapsody	: 8.1.1
	Login		: Le F�lix
	Component	: Exe
	Configuration 	: Host
	Model Element	: approvedAccess
//!	Generated Date	: Sat, 12, Mar 2016 
	File Path	: Exe/Host/Scada/approvedAccess.java
*********************************************************************/

package Scada;

//## auto_generated
import com.ibm.rational.rhapsody.animation.*;
//## auto_generated
import com.ibm.rational.rhapsody.oxf.RiJEvent;
//## auto_generated
import com.ibm.rational.rhapsody.animcom.animMessages.*;

//----------------------------------------------------------------------------
// Scada/approvedAccess.java                                                                  
//----------------------------------------------------------------------------

//## package Scada 


//## event approvedAccess() 
public class approvedAccess extends RiJEvent implements AnimatedEvent {
    
    public static final int approvedAccess_Scada_id = 2830;		//## ignore 
    
    
    // Constructors
    
    public  approvedAccess() {
        lId = approvedAccess_Scada_id;
    }
    
    public boolean isTypeOf(long id) {
        return (approvedAccess_Scada_id==id);
    }
    
    //#[ ignore
    /** the animated event proxy */
    public static AnimEventClass animClass = new AnimEventClass("Scada.approvedAccess");
    /**  see com.ibm.rational.rhapsody.animation.AnimatedEvent interface */
    public Object getFieldValue(java.lang.reflect.Field f, Object userInstance) { 
         Object obj = null;
         try {
             obj = f.get(userInstance);
         } catch(Exception e) {
              java.lang.System.err.println("Exception: getting Field value: " + e);
              e.printStackTrace();
         }
         return obj;
    }
    /**  see com.ibm.rational.rhapsody.animation.AnimatedEvent interface */
    public void addAttributes(AnimAttributes msg) {      
    }
    public String toString() {
          String s="approvedAccess(";      
          s += ")";
          return s;
    }
    //#]
    
}
/*********************************************************************
	File Path	: Exe/Host/Scada/approvedAccess.java
*********************************************************************/


/*********************************************************************
	Rhapsody	: 8.1.1
	Login		: Le F�lix
	Component	: Exe
	Configuration 	: Host
	Model Element	: ckeckPolicy
//!	Generated Date	: Sat, 12, Mar 2016 
	File Path	: Exe/Host/Scada/ckeckPolicy.java
*********************************************************************/

package Scada;

//## auto_generated
import com.ibm.rational.rhapsody.animation.*;
//## auto_generated
import com.ibm.rational.rhapsody.oxf.RiJEvent;
//## auto_generated
import com.ibm.rational.rhapsody.animcom.animMessages.*;

//----------------------------------------------------------------------------
// Scada/ckeckPolicy.java                                                                  
//----------------------------------------------------------------------------

//## package Scada 


//## event ckeckPolicy() 
public class ckeckPolicy extends RiJEvent implements AnimatedEvent {
    
    public static final int ckeckPolicy_Scada_id = 2833;		//## ignore 
    
    
    // Constructors
    
    public  ckeckPolicy() {
        lId = ckeckPolicy_Scada_id;
    }
    
    public boolean isTypeOf(long id) {
        return (ckeckPolicy_Scada_id==id);
    }
    
    //#[ ignore
    /** the animated event proxy */
    public static AnimEventClass animClass = new AnimEventClass("Scada.ckeckPolicy");
    /**  see com.ibm.rational.rhapsody.animation.AnimatedEvent interface */
    public Object getFieldValue(java.lang.reflect.Field f, Object userInstance) { 
         Object obj = null;
         try {
             obj = f.get(userInstance);
         } catch(Exception e) {
              java.lang.System.err.println("Exception: getting Field value: " + e);
              e.printStackTrace();
         }
         return obj;
    }
    /**  see com.ibm.rational.rhapsody.animation.AnimatedEvent interface */
    public void addAttributes(AnimAttributes msg) {      
    }
    public String toString() {
          String s="ckeckPolicy(";      
          s += ")";
          return s;
    }
    //#]
    
}
/*********************************************************************
	File Path	: Exe/Host/Scada/ckeckPolicy.java
*********************************************************************/


/*********************************************************************
	Rhapsody	: 8.1.1
	Login		: Le F�lix
	Component	: Exe
	Configuration 	: Host
	Model Element	: end
//!	Generated Date	: Sat, 12, Mar 2016 
	File Path	: Exe/Host/Scada/end.java
*********************************************************************/

package Scada;

//## auto_generated
import com.ibm.rational.rhapsody.animation.*;
//## auto_generated
import com.ibm.rational.rhapsody.oxf.RiJEvent;
//## auto_generated
import com.ibm.rational.rhapsody.animcom.animMessages.*;

//----------------------------------------------------------------------------
// Scada/end.java                                                                  
//----------------------------------------------------------------------------

//## package Scada 


//## event end() 
public class end extends RiJEvent implements AnimatedEvent {
    
    public static final int end_Scada_id = 2822;		//## ignore 
    
    
    // Constructors
    
    public  end() {
        lId = end_Scada_id;
    }
    
    public boolean isTypeOf(long id) {
        return (end_Scada_id==id);
    }
    
    //#[ ignore
    /** the animated event proxy */
    public static AnimEventClass animClass = new AnimEventClass("Scada.end");
    /**  see com.ibm.rational.rhapsody.animation.AnimatedEvent interface */
    public Object getFieldValue(java.lang.reflect.Field f, Object userInstance) { 
         Object obj = null;
         try {
             obj = f.get(userInstance);
         } catch(Exception e) {
              java.lang.System.err.println("Exception: getting Field value: " + e);
              e.printStackTrace();
         }
         return obj;
    }
    /**  see com.ibm.rational.rhapsody.animation.AnimatedEvent interface */
    public void addAttributes(AnimAttributes msg) {      
    }
    public String toString() {
          String s="end(";      
          s += ")";
          return s;
    }
    //#]
    
}
/*********************************************************************
	File Path	: Exe/Host/Scada/end.java
*********************************************************************/


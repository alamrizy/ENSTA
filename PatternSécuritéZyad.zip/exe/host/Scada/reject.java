/*********************************************************************
	Rhapsody	: 8.1.1
	Login		: Le F�lix
	Component	: Exe
	Configuration 	: Host
	Model Element	: reject
//!	Generated Date	: Sat, 12, Mar 2016 
	File Path	: Exe/Host/Scada/reject.java
*********************************************************************/

package Scada;

//## auto_generated
import com.ibm.rational.rhapsody.animation.*;
//## auto_generated
import com.ibm.rational.rhapsody.oxf.RiJEvent;
//## auto_generated
import com.ibm.rational.rhapsody.animcom.animMessages.*;

//----------------------------------------------------------------------------
// Scada/reject.java                                                                  
//----------------------------------------------------------------------------

//## package Scada 


//## event reject() 
public class reject extends RiJEvent implements AnimatedEvent {
    
    public static final int reject_Scada_id = 2818;		//## ignore 
    
    
    // Constructors
    
    public  reject() {
        lId = reject_Scada_id;
    }
    
    public boolean isTypeOf(long id) {
        return (reject_Scada_id==id);
    }
    
    //#[ ignore
    /** the animated event proxy */
    public static AnimEventClass animClass = new AnimEventClass("Scada.reject");
    /**  see com.ibm.rational.rhapsody.animation.AnimatedEvent interface */
    public Object getFieldValue(java.lang.reflect.Field f, Object userInstance) { 
         Object obj = null;
         try {
             obj = f.get(userInstance);
         } catch(Exception e) {
              java.lang.System.err.println("Exception: getting Field value: " + e);
              e.printStackTrace();
         }
         return obj;
    }
    /**  see com.ibm.rational.rhapsody.animation.AnimatedEvent interface */
    public void addAttributes(AnimAttributes msg) {      
    }
    public String toString() {
          String s="reject(";      
          s += ")";
          return s;
    }
    //#]
    
}
/*********************************************************************
	File Path	: Exe/Host/Scada/reject.java
*********************************************************************/

